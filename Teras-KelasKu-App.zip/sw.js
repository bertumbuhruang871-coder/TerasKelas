// Service Worker - Teras KelasKu
// Menyimpan file inti aplikasi (termasuk library CDN) agar tetap bisa dibuka meski koneksi internet terputus.

const CACHE_NAME = 'teras-kelasku-cache-v3';
const CORE_ASSETS = [
  './',
  './index.html',
  './PerangkatDigitaEdar.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png',
  './apple-touch-icon.png',
  './favicon-16.png',
  './favicon-32.png',
  'https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4',
  'https://cdn.jsdelivr.net/npm/chart.js',
  'https://unpkg.com/lucide@latest',
  'https://cdnjs.cloudflare.com/ajax/libs/exceljs/4.4.0/exceljs.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.0.379/pdf.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.0.379/pdf.worker.min.js',
  'https://cdn.jsdelivr.net/npm/mammoth/mammoth.browser.min.js',
  'https://fonts.googleapis.com/css2?family=Caveat:wght=600;700&family=Nunito:wght=400;600;700&family=Poppins:wght=400;500;600;700&display=swap'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) =>
      Promise.all(CORE_ASSETS.map((url) => cache.add(url).catch(() => {})))
    )
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  // Coba jaringan dulu (biar selalu dapat versi terbaru saat online),
  // kalau gagal (offline) pakai salinan dari cache.
  // Termasuk file dari CDN (Tailwind, Chart.js, dll) yang bersifat cross-origin.
  event.respondWith(
    fetch(event.request)
      .then((response) => {
        const copy = response.clone();
        // response.status 0 berarti "opaque" (respons dari CDN cross-origin) - tetap disimpan.
        if (response.status === 200 || response.type === 'opaque') {
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
        }
        return response;
      })
      .catch(() => caches.match(event.request).then((cached) => cached || caches.match('./index.html')))
  );
});
